Cursus for Commerce
-------------------

Connect Commerce with Cursus to confirm event registrations when payment is confirmed.
