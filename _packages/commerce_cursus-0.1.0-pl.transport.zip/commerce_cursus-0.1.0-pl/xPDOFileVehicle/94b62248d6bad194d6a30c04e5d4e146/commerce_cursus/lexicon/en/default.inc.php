<?php

$_lang['commerce_cursus'] = 'Cursus';
$_lang['commerce_cursus.description'] = 'Connect Commerce with Cursus to confirm event registrations when payment is confirmed.';
